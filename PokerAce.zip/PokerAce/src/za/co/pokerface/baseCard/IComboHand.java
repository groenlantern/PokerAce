package za.co.pokerface.baseCard;


/**
 * 
 * @author Jean-Pierre Erasmus 
 * 
 * 
 * This interface should only be implemented by ENUM's
 *
 */
public interface IComboHand extends ICardInfo {
	public String getLabel();
	
}
