package za.co.pokerface.baseCard;
import java.util.ArrayList;

public interface ShuffleDelegate {

	ArrayList<Card> shuffleDeck(  ArrayList<Card> deck );

}
