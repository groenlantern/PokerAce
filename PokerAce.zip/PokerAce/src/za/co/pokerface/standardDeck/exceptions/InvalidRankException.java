/**
 * 
 */
package za.co.pokerface.standardDeck.exceptions;

/**
 * @author Jean-Pierre Erasmus
 *
 */
public class InvalidRankException extends Exception {

	/**
	 * 
	 * @param message
	 */
	public InvalidRankException(String message) {
		super(message);
		 
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
}
