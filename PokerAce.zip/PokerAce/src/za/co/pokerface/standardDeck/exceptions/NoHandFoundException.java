/**
 * 
 */
package za.co.pokerface.standardDeck.exceptions;

/**
 * @author Jean-Pierre Erasmus
 *
 */
public class NoHandFoundException extends Exception {

	/**
	 * 
	 * @param message
	 */
	public NoHandFoundException(String message) {
		super(message);
		 
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
}
