/**
 * 
 */
package za.co.pokerface.standardDeck.exceptions;

/**
 * @author Jean-Pierre Erasmus
 *
 */
public class NoPIPFoundException extends Exception {

	/**
	 * 
	 * @param message
	 */
	public NoPIPFoundException(String message) {
		super(message);
		 
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
}
